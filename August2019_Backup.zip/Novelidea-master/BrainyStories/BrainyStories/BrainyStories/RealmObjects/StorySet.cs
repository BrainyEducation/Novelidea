﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BrainyStories.RealmObjects
{
    public enum StorySet
    {
        Imagines = 1,
        StorySet1 = 2
    }
}