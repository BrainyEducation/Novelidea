﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BrainyStories.RealmObjects
{
    // AppealType associated with each classic story
    public enum AppealType
    {
        Male = 0,
        Female = 1,
        General = 2,
        Animal = 3
    }
}