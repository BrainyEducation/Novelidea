# NovelIdea
- A children's app where children can read or listen to stories and increase their reading comprehension skills.
- Stories taken from hearatale.org

## Refactoring Brainy Stories - June 2019 to August 2019
#### Key Changes
   - Added a database to persist data across sessions
   - Shrunk app size by removing some media content and changing build settings to Link some SDKs
   - Various User-Interface tweaks, as instructed by Walter
   - Restructured code to use best coding practices
   - Fixed crashes related to playing stories.    
